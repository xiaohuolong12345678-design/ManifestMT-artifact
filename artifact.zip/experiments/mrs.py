"""ManifestMT metamorphic relations: rewriters with executable preconditions.

An MR instance is applied only if the executable precondition holds:
the original and rewritten specifier sets select the SAME subset of the
frozen candidate version list for that package (index snapshot).
"""
from __future__ import annotations
import json, random, re
from functools import lru_cache
from pathlib import Path

import urllib.request

try:
    from packaging.requirements import Requirement
    from packaging.specifiers import SpecifierSet
    from packaging.utils import canonicalize_name
except ImportError:
    raise SystemExit("pip install packaging")

from resolvers import MIRROR  # noqa: F401  (kept for symmetry)

UA = {"User-Agent": "manifestmt-research/0.1"}
CACHE = Path("/tmp/mmt/candidates")
CACHE.mkdir(parents=True, exist_ok=True)


def candidate_versions(pkg: str) -> list[str]:
    key = CACHE / (pkg.lower().replace("/", "_") + ".json")
    if key.exists():
        return json.loads(key.read_text())
    url = f"https://pypi.tuna.tsinghua.edu.cn/pypi/{pkg}/json"
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        d = json.loads(r.read())
    versions = sorted(d.get("releases", {}).keys())
    key.write_text(json.dumps(versions))
    return versions


def selects_same(spec_a: str, spec_b: str, candidates: list[str]) -> bool:
    """Programmatic equivalence on the frozen candidate set (incl. prereleases)."""
    sa = SpecifierSet(spec_a)
    sb = SpecifierSet(spec_b)
    return (
        {c for c in candidates if sa.contains(c, prereleases=True)}
        == {c for c in candidates if sb.contains(c, prereleases=True)}
    )


def selects(spec: str, candidates: list[str]) -> set[str]:
    s = SpecifierSet(spec)
    return {c for c in candidates if s.contains(c, prereleases=True)}


def _usable(req: Requirement) -> bool:
    return req.url is None


# ---------------- MR families ----------------

def mr1_split(req: Requirement) -> list[str] | None:
    """pkg>=13,<16  ->  pkg>=13 ; pkg<16  (same marker)."""
    specs = [str(s) for s in req.specifier]
    if len(specs) < 2 or req.extras or req.url:
        return None
    marker = f" ; {req.marker}" if req.marker else ""
    return [f"{req.name}{s}{marker}" for s in specs]


def mr2_normalform(req: Requirement) -> str | None:
    """pkg==1.2.* -> pkg~=1.2.0 ; pkg==1.* -> pkg>=1,<2 (one direction)."""
    if req.extras or req.url or len(list(req.specifier)) != 1:
        return None
    s = list(req.specifier)[0]
    if s.operator != "==":
        return None
    v = s.version
    m = re.fullmatch(r"(\d+)\.(\d+)\.\*", v)
    if m:
        return f"{req.name}~={m.group(1)}.{m.group(2)}.0"
    m = re.fullmatch(r"(\d+)\.\*", v)
    if m:
        x = int(m.group(1))
        return f"{req.name}>={x},<{x + 1}"
    return None


def mr4_merge(reqs: list[Requirement], idx: list[int]) -> str | None:
    """merge duplicate entries (same marker) into one combined constraint."""
    base = reqs[idx[0]]
    if base.url or base.extras:
        return None
    for i in idx[1:]:
        r = reqs[i]
        if r.url or r.extras or (str(r.marker) != str(base.marker)):
            return None
    combined = SpecifierSet()
    for i in idx:
        combined &= reqs[i].specifier
    line = f"{base.name}{combined}"
    if base.marker:
        line += f" ; {base.marker}"
    return line


def mr5_shuffle(lines: list[str], rng: random.Random) -> list[str]:
    ls = lines[:]
    rng.shuffle(ls)
    return ls


def mr6_format(lines: list[str]) -> list[str]:
    """Comments + whitespace only. NOT case-folding: marker *values* (e.g.
    platform_python_implementation == "CPython") are case-sensitive, so
    lowercasing is NOT semantics-preserving."""
    out = ["# manifestmt format-equivalence probe", ""]
    for i, ln in enumerate(lines):
        out.append(ln)
        if i == 0:
            out.append("")
    out += ["", "# end"]
    return out


# ---------------- instance builder ----------------

def build_instances(manifest_lines: list[str], rng: random.Random,
                    baseline_pins: dict[str, str] | None = None,
                    manifest_pkg_names: set[str] | None = None) -> list[dict]:
    """Return MR instances: {mr, lines, note}. Precondition-verified.

    baseline_pins: required for MR3 (redundant-constraint injection).
    manifest_pkg_names: names already present in the manifest (MR3 must avoid).
    """
    reqs: list[Requirement] = []
    for ln in manifest_lines:
        try:
            reqs.append(Requirement(ln))
        except Exception:  # noqa: BLE001
            reqs.append(None)  # type: ignore
    usable = [(i, r) for i, r in enumerate(reqs) if r is not None and _usable(r)]
    instances: list[dict] = []
    cand_cache: dict[str, list[str]] = {}

    def cands(name: str) -> list[str]:
        if name not in cand_cache:
            try:
                cand_cache[name] = candidate_versions(name)
            except Exception:  # noqa: BLE001
                cand_cache[name] = []
        return cand_cache[name]

    # MR1 split (first 3 applicable deps)
    n_done = 0
    for i, r in usable:
        if n_done >= 3:
            break
        parts = mr1_split(r)
        if not parts:
            continue
        c = cands(r.name)
        if not c:
            continue
        specs = [str(sp) for sp in r.specifier]
        # split entries are ANDed by the resolver -> intersection must equal combined
        inter = selects(specs[0], c)
        for sp in specs[1:]:
            inter &= selects(sp, c)
        ok = ({v for v in c if r.specifier.contains(v, prereleases=True)} == inter)
        if not ok:
            continue
        new_lines = [ln for j, ln in enumerate(manifest_lines) if j != i] + parts
        instances.append({"mr": "MR1", "lines": new_lines, "note": f"split {r.name}"})
        n_done += 1

    # MR2 wildcard normal form
    for i, r in usable:
        nf = mr2_normalform(r)
        if not nf:
            continue
        c = cands(r.name)
        if not c:
            continue
        orig_spec = str(r.specifier)
        new_spec = nf[len(r.name):]
        if not selects_same(orig_spec, new_spec, c):
            continue
        new_lines = list(manifest_lines)
        new_lines[i] = nf + (f" ; {r.marker}" if r.marker else "")
        instances.append({"mr": "MR2", "lines": new_lines, "note": f"normalform {r.name}"})
        break

    # MR4 duplicate merge
    by_name: dict[str, list[int]] = {}
    for i, r in usable:
        by_name.setdefault(canonicalize_name(r.name), []).append(i)
    for name, idxs in by_name.items():
        if len(idxs) < 2:
            continue
        merged = mr4_merge([r for _, r in usable], idxs)
        if not merged:
            continue
        r0 = reqs[idxs[0]]
        c = cands(name)
        if not c:
            continue
        old_sel = {v for v in c if r0.specifier.contains(v, prereleases=True)}
        for i in idxs[1:]:
            old_sel &= {v for v in c if reqs[i].specifier.contains(v, prereleases=True)}
        m = Requirement(merged)
        if {v for v in c if m.specifier.contains(v, prereleases=True)} != old_sel:
            continue
        keep = [ln for j, ln in enumerate(manifest_lines) if j not in set(idxs)]
        instances.append({"mr": "MR4", "lines": keep + [merged], "note": f"merge {name}"})
        break

    # MR5 shuffle (2 instances with different seeds)
    if len(manifest_lines) >= 2:
        for k in range(2):
            instances.append({
                "mr": "MR5", "lines": mr5_shuffle(manifest_lines, rng),
                "note": f"shuffle seed {rng.randrange(10**6)}",
            })

    # MR6 formatting
    instances.append({"mr": "MR6", "lines": mr6_format(manifest_lines), "note": "comments/whitespace"})

    # MR3 redundant-constraint injection (needs baseline closure)
    if baseline_pins and manifest_pkg_names is not None:
        injected = 0
        for dep, ver in sorted(baseline_pins.items()):
            if injected >= 2:
                break
            if dep in {canonicalize_name(n) for n in manifest_pkg_names}:
                continue
            if not re.fullmatch(r"[0-9][0-9A-Za-z._+-]*", ver or ""):
                continue
            new_lines = list(manifest_lines) + [f"{dep}=={ver}"]
            instances.append({
                "mr": "MR3", "lines": new_lines,
                "note": f"inject transitive {dep}=={ver}",
            })
            injected += 1

    return instances
