"""ManifestMT scenario runner.

Per (project, resolver):
  1. clean baseline resolution
  2. build precondition-verified MR instances (MR3 uses baseline closure)
  3. run each instance in a fresh dir, compare pin sets
  4. DIVERGENT cases are re-run clean (replay) to split
     EXTERNAL-STATE-DRIFT vs REPLAYABLE-FORM-SENSITIVITY

Output: JSONL records, one per (project, mr, resolver).
"""
from __future__ import annotations
import argparse, hashlib, json, random, shutil, tempfile, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import resolvers
from resolvers import RESOLVERS, ResolverError, tool_versions
import mrs

try:
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name
except ImportError:
    raise SystemExit("pip install packaging")

HERE = Path(__file__).resolve().parent
WORKROOT = Path("/tmp/mmt/work")
ONLY_MR = None


def clean_names(lines: list[str]) -> set[str]:
    out = set()
    for ln in lines:
        try:
            out.add(canonicalize_name(Requirement(ln).name))
        except Exception:  # noqa: BLE001
            pass
    return out


def run_one(project: dict, resolver: str, lines: list[str], tag: str,
            replay_of: str | None = None) -> dict:
    import shutil as _sh
    free = _sh.disk_usage(str(WORKROOT)).free
    if free < 2_000_000_000:
        return {"project": project["name"], "resolver": resolver, "tag": tag,
                "status": "DISK_LOW", "error": f"only {free/1e9:.1f}GB free"}
    d = Path(tempfile.mkdtemp(prefix="mmt_", dir=WORKROOT))
    t0 = time.time()
    rec = {
        "project": project["name"], "version": project.get("version"),
        "resolver": resolver, "tag": tag, "replay_of": replay_of,
        "n_deps": len(project["requires_dist"]),
        "stratum": project.get("stratum"),
    }
    try:
        pins = RESOLVERS[resolver](lines, d)
        rec.update(status="OK", pins=pins, elapsed_ms=int((time.time() - t0) * 1000))
    except ResolverError as e:
        rec.update(status=e.kind, error=str(e)[-500:], elapsed_ms=int((time.time() - t0) * 1000))
    except Exception as e:  # noqa: BLE001
        rec.update(status="CRASH", error=str(e)[-500:], elapsed_ms=int((time.time() - t0) * 1000))
    finally:
        shutil.rmtree(d, ignore_errors=True)
    return rec


def scenario(project: dict, resolver: str) -> list[dict]:
    manifest = [ln for ln in project["requires_dist"] if isinstance(ln, str) and ln.strip()]
    if not manifest:
        return []
    out: list[dict] = []
    base = run_one(project, resolver, manifest, "baseline")
    out.append(base)
    if base["status"] != "OK":
        return out
    base_pins = base["pins"]
    rng = random.Random(hash((project["name"], resolver)) & 0xFFFFFFF)
    try:
        instances = mrs.build_instances(
            manifest, rng, baseline_pins=base_pins,
            manifest_pkg_names=clean_names(manifest),
        )
    except Exception as e:  # noqa: BLE001
        out.append({"project": project["name"], "resolver": resolver, "tag": "instance-gen",
                    "status": "GEN_FAIL", "error": str(e)[-300:]})
        return out
    for inst in instances:
        if ONLY_MR and inst["mr"] != ONLY_MR:
            continue
        arm = run_one(project, resolver, inst["lines"], inst["mr"])
        h = hashlib.sha256("\n".join(inst["lines"]).encode()).hexdigest()[:12]
        rec = {
            "project": project["name"], "version": project.get("version"),
            "resolver": resolver, "mr": inst["mr"], "note": inst["note"],
            "req_hash": h, "stratum": project.get("stratum"),
            "arm_lines": inst["lines"],
            "baseline_status": "OK", "baseline_pins": base_pins,
            "arm_status": arm["status"], "arm_pins": arm.get("pins"),
            "arm_error": arm.get("error"),
            "elapsed_ms": arm.get("elapsed_ms"),
        }
        if arm["status"] == "OK":
            diff = {
                "changed": {k: [base_pins.get(k), v] for k, v in arm["pins"].items()
                            if base_pins.get(k) != v},
                "missing": sorted(set(base_pins) - set(arm["pins"])),
                "added": sorted(set(arm["pins"]) - set(base_pins)),
            }
            rec["diff"] = diff
            rec["status"] = "IDENTICAL" if not (diff["changed"] or diff["missing"] or diff["added"]) else "DIVERGENT"
        else:
            rec["status"] = "ARM_" + arm["status"]
        out.append(rec)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default=str(HERE / "data" / "corpus.jsonl"))
    ap.add_argument("--resolvers", default="uv,pip-tools")
    ap.add_argument("--n", type=int, default=120)
    ap.add_argument("--max-deps", type=int, default=40)
    ap.add_argument("--out", default=str(HERE / "data" / "results.jsonl"))
    ap.add_argument("--workers", type=int, default=10)
    ap.add_argument("--limit-project", default=None,
                    help="restrict to one project name (debug)")
    ap.add_argument("--only-mr", default=None, help="restrict to one MR family")
    ap.add_argument("--append", action="store_true",
                    help="resume: append to --out, skipping finished (project,resolver)")
    args = ap.parse_args()

    global ONLY_MR
    ONLY_MR = args.only_mr
    WORKROOT.mkdir(parents=True, exist_ok=True)
    corpus = [json.loads(l) for l in open(args.corpus)]
    resv = args.resolvers.split(",")

    # project selection: interleaved strata, capped deps
    def usable(p: dict) -> bool:
        lines = [l for l in p["requires_dist"] if isinstance(l, str) and l.strip()]
        ok = 0
        for l in lines:
            try:
                r = Requirement(l)
                if r.url is None:
                    ok += 1
            except Exception:  # noqa: BLE001
                pass
        return 1 <= ok <= args.max_deps

    pool = [p for p in corpus if usable(p)]
    seed_pool = [p for p in pool if p.get("stratum") == "seed"]
    uni_pool = [p for p in pool if p.get("stratum") != "seed"]
    half = args.n // 2
    chosen = seed_pool[:half] + uni_pool[: max(0, args.n - half)]
    if args.limit_project:
        chosen = [p for p in corpus if p["name"].lower() == args.limit_project.lower()]
    print(f"projects: {len(chosen)}  resolvers: {resv}", flush=True)

    import time as _t
    t0 = _t.time()
    jobs = [(p, r) for p in chosen for r in resv]
    done_pairs = set()
    if args.append and Path(args.out).exists():
        for line in open(args.out):
            try:
                d = json.loads(line)
                done_pairs.add((d.get("project"), d.get("resolver")))
            except Exception:  # noqa: BLE001
                pass
        jobs = [(p, r) for p, r in jobs if (p["name"], r) not in done_pairs]
        print(f"resume: {len(done_pairs)} pairs done, {len(jobs)} to go", flush=True)
    n_records = 0
    mode = "a" if args.append else "w"
    with open(args.out, mode) as fout, ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(scenario, p, r): (p["name"], r) for p, r in jobs}
        for i, fut in enumerate(as_completed(futs), 1):
            try:
                recs = fut.result()
            except Exception as e:  # noqa: BLE001
                recs = [{"project": futs[fut][0], "resolver": futs[fut][1],
                         "status": "SCENARIO_CRASH", "error": str(e)[-300:]}]
            for r in recs:
                fout.write(json.dumps(r, ensure_ascii=False) + "\n")
            n_records += len(recs)
            fout.flush()
            if i % 10 == 0:
                print(f"[{_t.time()-t0:6.0f}s] {i}/{len(jobs)} scenarios, {n_records} records",
                      flush=True)
    print(f"done: {n_records} records -> {args.out} in {_t.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
