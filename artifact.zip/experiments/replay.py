"""Replay + classify DIVERGENT scenarios from a results JSONL.

For each DIVERGENT record: re-run baseline and arm cleanly. If identical
now -> EXTERNAL-STATE-DRIFT; else REPLAYABLE-FORM-SENSITIVITY, with a
heuristic root cause (pre-release / yanked / promotion / other).

Also re-runs a random sample of IDENTICAL records as a stability control.

Output: <in>.classified.jsonl (all records, replay fields added).
"""
from __future__ import annotations
import argparse, json, random, sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

sys.path.insert(0, str(Path(__file__).parent))
from runner import run_one  # noqa: E402


def load_corpus_manifests(path: str) -> dict[str, list[str]]:
    from pathlib import Path as P
    p = P(path)
    if not p.exists():
        p = P(__file__).parent / "data" / "corpus.jsonl"
    out = {}
    for line in open(p):
        d = json.loads(line)
        out[d["name"].lower()] = [l for l in d["requires_dist"] if isinstance(l, str) and l.strip()]
    return out


def _rootcause(rec: dict, corpus: dict) -> str:
    diff = rec.get("diff") or {}
    names = set(diff.get("changed", {})) | set(diff.get("added", [])) | set(diff.get("missing", []))
    if not names:
        return "EMPTY-DIFF"
    manifest_names = {n.lower() for n in corpus.get(rec["project"].lower(), [])}
    try:
        from packaging.utils import canonicalize_name
        manifest_names = {canonicalize_name(n) for n in manifest_names}
    except Exception:  # noqa: BLE001
        pass
    for _k, pair in (diff.get("changed") or {}).items():
        old, new = pair
        if old and new and old != new and any(ch in new for ch in (".a", ".b", ".rc", ".dev")):
            return "PRE_RELEASE_ADMISSION"
    if rec["mr"] == "MR3":
        return "PROMOTION"
    if names & (manifest_names or set()):
        return "DIRECT_DEP_TOUCHED"
    return "OTHER"


def replay_one(task: tuple) -> dict:
    rec, manifest = task
    proj = {"name": rec["project"], "version": rec.get("version"),
            "requires_dist": manifest, "stratum": rec.get("stratum")}
    base = run_one(proj, rec["resolver"], manifest, "replay-baseline")
    arm = run_one(proj, rec["resolver"], rec["arm_lines"], "replay-arm")
    out = dict(rec)
    out["replay"] = {
        "baseline_status": base["status"], "arm_status": arm["status"],
        "baseline_pins": base.get("pins"), "arm_pins": arm.get("pins"),
    }
    if base["status"] == "OK" and arm["status"] == "OK":
        same = base["pins"] == arm["pins"]
        if same:
            out["classification"] = ("STABLE_CONTROL"
                                     if rec.get("status") == "IDENTICAL"
                                     else "EXTERNAL_STATE_DRIFT")
        else:
            out["classification"] = "REPLAYABLE_FORM_SENSITIVITY"
            d2 = {
                "changed": {k: [base["pins"].get(k), v] for k, v in arm["pins"].items()
                            if base["pins"].get(k) != v},
                "missing": sorted(set(base["pins"]) - set(arm["pins"])),
                "added": sorted(set(arm["pins"]) - set(base["pins"])),
            }
            out["replay_diff"] = d2
            out["rootcause"] = _rootcause({**rec, "diff": d2}, corpus_manifests)
    else:
        out["classification"] = "REPLAY_NON_OK"
    return out


corpus_manifests: dict[str, list[str]] = {}


def main() -> None:
    global corpus_manifests
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--corpus", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--identical-sample", type=int, default=30,
                    help="random IDENTICAL records to re-run as stability control")
    args = ap.parse_args()

    corpus_manifests = load_corpus_manifests(args.corpus) if args.corpus else \
        load_corpus_manifests(str(Path(__file__).parent / "data" / "corpus.jsonl"))

    recs = [json.loads(l) for l in open(args.inp)]
    tasks: list[tuple] = []
    div = [r for r in recs if r.get("status") == "DIVERGENT"]
    ident = [r for r in recs if r.get("status") == "IDENTICAL"]
    rng = random.Random(20260904)
    for r in div:
        m = corpus_manifests.get(r["project"].lower())
        if m and r.get("arm_lines"):
            tasks.append((r, m))
    for r in rng.sample(ident, min(args.identical_sample, len(ident))):
        m = corpus_manifests.get(r["project"].lower())
        if m and r.get("arm_lines"):
            tasks.append((r, m))
    print(f"replaying {len(tasks)} records ({len(div)} divergent, "
          f"{len(tasks)-len(div)} identical-sample)", flush=True)

    out_path = args.out or (args.inp.replace(".jsonl", "") + ".classified.jsonl")
    replayed_keys = set()
    with open(out_path, "w") as fout, ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(replay_one, t): t[0] for t in tasks}
        done = 0
        for fut in as_completed(futs):
            try:
                rec = fut.result()
            except Exception as e:  # noqa: BLE001
                rec = {"project": futs[fut]["project"], "resolver": futs[fut]["resolver"],
                       "mr": futs[fut].get("mr"), "req_hash": futs[fut].get("req_hash"),
                       "classification": "REPLAY_CRASH", "error": str(e)[-300:]}
            key = (rec["project"], rec["resolver"], rec.get("req_hash"))
            replayed_keys.add(key)
            fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
            done += 1
            if done % 10 == 0:
                print(f"  replayed {done}/{len(tasks)}", flush=True)

    # merged output: original records + replay annotations
    import copy
    def keyf(r):
        return (r.get("project"), r.get("resolver"), r.get("req_hash"))
    replay_map = {}
    for line in open(out_path):
        d = json.loads(line)
        replay_map[keyf(d)] = d
    merged_path = out_path.replace(".classified.jsonl", "") + ".merged.jsonl"
    with open(merged_path, "w") as fm:
        for r in recs:
            r2 = dict(r)
            info = replay_map.get(keyf(r))
            if info and r.get("status") in ("DIVERGENT", "IDENTICAL"):
                r2["classification"] = info.get("classification")
                if info.get("rootcause"):
                    r2["rootcause"] = info["rootcause"]
                if info.get("replay_diff"):
                    r2["replay_diff"] = info["replay_diff"]
                if r["status"] == "DIVERGENT" and info.get("classification") is None:
                    r2["classification"] = info.get("classification", "REPLAY_NON_OK")
            fm.write(json.dumps(r2, ensure_ascii=False) + "\n")
    print(f"classified -> {out_path}\nmerged     -> {merged_path}", flush=True)


if __name__ == "__main__":
    main()
