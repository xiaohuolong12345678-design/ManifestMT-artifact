"""ManifestMT analysis: tables, stats, figures — all numbers generated
programmatically from result JSONL files (no hand transcription).

Inputs (in data/):
  results_e0.jsonl + results_e0.merged.jsonl   (E0 gate)
  results_e1a.jsonl                            (E1 uv+pip-tools full)
  results_e1b.jsonl                            (E1 poetry+pdm subsample)
  drift_results.jsonl                          (E3)
  impact_results.jsonl                         (E2)

Outputs (in out/):
  tables.tex fragments + figures PDF + summary.json
"""
from __future__ import annotations
import json, math, random
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
OUT = HERE / "out"
OUT.mkdir(exist_ok=True)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 9, "axes.grid": True, "grid.alpha": .3,
    "figure.dpi": 150, "savefig.bbox": "tight",
})


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float, float]:
    if n == 0:
        return (float("nan"),) * 3
    p = k / n
    den = 1 + z ** 2 / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return p, max(0.0, centre - half), min(1.0, centre + half)


def load(name: str) -> list[dict]:
    p = DATA / name
    if not p.exists():
        return []
    return [json.loads(l) for l in open(p)]


def e1_table(patterns: list[str], label: str) -> dict:
    """MR x resolver -> (N arms valid, identical, divergent) + Wilson CIs."""
    recs = []
    for pat in patterns:
        recs += load(pat)
    arms = [r for r in recs if r.get("mr") and r["status"] in ("IDENTICAL", "DIVERGENT")]
    base = [r for r in recs if r.get("tag") == "baseline"]
    grid = defaultdict(lambda: [0, 0])
    for r in arms:
        g = grid[(r["mr"], r["resolver"])]
        g[0] += 1
        if r["status"] == "DIVERGENT":
            g[1] += 1
    stats = {}
    for (mr, res), (n, k) in sorted(grid.items()):
        p, lo, hi = wilson(k, n)
        stats[f"{mr}|{res}"] = {"n": n, "divergent": k, "rate": p,
                                "lo": lo, "hi": hi}
    summary = {
        "scenarios": len(base),
        "baseline_status": dict(Counter(r["status"] for r in base)),
        "arms": dict(Counter(r["status"] for r in arms)),
        "grid": stats,
    }
    (OUT / f"summary_{label}.json").write_text(json.dumps(summary, indent=1))
    return summary


def fig_invariance(summary: dict, name: str, title: str) -> None:
    mrs = sorted({k.split("|")[0] for k in summary["grid"]})
    resolvers = sorted({k.split("|")[1] for k in summary["grid"]})
    fig, ax = plt.subplots(figsize=(1.6 + 1.1 * len(mrs), 2.9))
    width = 0.8 / len(resolvers)
    xs = np.arange(len(mrs))
    for i, res in enumerate(resolvers):
        ns, ks, los, his = [], [], [], []
        for mr in mrs:
            g = summary["grid"].get(f"{mr}|{res}")
            if g:
                ns.append(g["n"]); ks.append(g["divergent"])
                los.append(g["lo"]); his.append(g["hi"])
            else:
                ns.append(0); ks.append(0); los.append(0); his.append(0)
        rates = [k / n if n else 0 for k, n in zip(ks, ns)]
        err = [[r - l for r, l in zip(rates, los)],
               [h - r for r, h in zip(rates, his)]]
        bars = ax.bar(xs + i * width, [r * 100 for r in rates], width * .92,
                      label=res, yerr=[[e * 100 for e in ee] for ee in err],
                      capsize=2)
    ax.set_xticks(xs + width * (len(resolvers) - 1) / 2)
    ax.set_xticklabels(mrs)
    ax.set_ylabel("divergence rate (%, Wilson 95% CI)")
    ax.set_title(title)
    ax.legend()
    fig.savefig(OUT / name)
    plt.close(fig)


def pygoss_case() -> dict:
    recs = load("results_e0.merged.jsonl")
    out = {}
    for r in recs:
        if r["project"].lower() == "pygoss" and r.get("mr") == "MR5":
            out.setdefault(r["resolver"], []).append({
                "req_hash": r.get("req_hash"), "status": r["status"],
                "classification": r.get("classification"),
                "diff": r.get("diff") or r.get("replay_diff"),
            })
    (OUT / "pygoss_case.json").write_text(json.dumps(out, indent=1))
    return out


def e3_analysis() -> dict:
    recs = load("drift_results.jsonl")
    per = defaultdict(list)  # policy -> list of drift_members / blocked
    adm = defaultdict(int); tot = defaultdict(int)
    for r in recs:
        if r.get("status") != "OK":
            continue
        pol = r["policy"]
        per[pol].append((r["drift_members"], len(r.get("blocked", []))))
        for lv, fv in r.get("levels", {}).items():
            tot[pol] += 1
            if fv in r.get("admitted", []):
                adm[pol] += 1
    summary = {}
    for pol, rows in per.items():
        drifts = [d for d, _ in rows]
        summary[pol] = {
            "n": len(rows),
            "drift_mean": float(np.mean(drifts)),
            "drift_p50": float(np.percentile(drifts, 50)),
            "drift_p90": float(np.percentile(drifts, 90)),
            "drift_max": int(max(drifts)),
            "pct_no_drift": 100 * sum(1 for d in drifts if d == 0) / len(rows),
            "admission_rate": adm[pol] / tot[pol] if tot[pol] else None,
        }
    (OUT / "summary_e3.json").write_text(json.dumps(summary, indent=1))
    # Pareto scatter
    fig, ax = plt.subplots(figsize=(3.6, 2.9))
    rng = random.Random(7)
    for pol, rows in per.items():
        xs = [b for _, b in rows]
        ys = [d for d, _ in rows]
        ax.scatter([x + rng.uniform(-.12, .12) for x in xs], ys, s=7, alpha=.45,
                   label=pol)
    ax.set_xlabel("# synthetic releases blocked (staleness)")
    ax.set_ylabel("closure drift (members changed)")
    ax.set_title("Drift exposure vs. staleness by declaration policy")
    ax.legend(fontsize=7)
    fig.savefig(OUT / "fig_e3_pareto.pdf")
    fig.savefig(OUT / "fig_e3_pareto.png")
    plt.close(fig)
    return summary


def mcnemar_paired(b: Counter) -> float:
    """exact binomial McNemar on discordant pairs (01 vs 10)."""
    from scipy.stats import binomtest
    n01, n10 = b["01"], b["10"]
    n = n01 + n10
    if n == 0:
        return float("nan")
    return binomtest(min(n01, n10), n, 0.5).pvalue


def e2_analysis() -> dict:
    recs = load("impact_results.jsonl")
    out = []
    for r in recs:
        def ids(arm):
            if not arm or "runs" not in arm:
                return None
            run = arm["runs"][0]
            return run
        base, cap, pin = ids(r["baseline"]), ids(r["cap"]), ids(r["pin_old"])
        if not (base and cap and pin):
            continue
        # second runs for flaky detection
        flaky_base = _diff_ids(r["baseline"])
        rec = {
            "project": r["project"], "dep": r["dep"], "top": r["top"], "prev": r["prev"],
            "base_fail": _fails(base), "cap_fail": _fails(cap), "pin_fail": _fails(pin),
            "base_flaky": sorted(flaky_base),
            "cap_parse": len(cap.get("parsed", {}) or {}),
        }
        out.append(rec)
    n = len(out)
    cap_break = sum(1 for r in out if r["cap_fail"] is None or r["cap_fail"] > 0) if out else 0
    summary = {"n_projects": n, "projects": out}
    (OUT / "summary_e2.json").write_text(json.dumps(summary, indent=1))
    return summary


def _fails(run) -> int | None:
    if run is None:
        return None
    if run["rc"] == 0:
        return 0
    p = run.get("parsed") or {}
    f = sum(1 for v in p.values() if v in ("FAILED", "ERROR"))
    return f if f > 0 else None  # rc!=0 but parse failed (e.g., collection error)


def _diff_ids(arm) -> list[str]:
    if not arm or len(arm.get("runs", [])) < 2:
        return []
    a, b = arm["runs"][0]["parsed"], arm["runs"][1]["parsed"]
    common = set(a) & set(b)
    return sorted(k for k in common if a[k] != b[k])


if __name__ == "__main__":
    import sys
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("all", "e0"):
        s0 = e1_table(["results_e0.jsonl"], "e0")
        fig_invariance(s0, "fig_e0_invariance.pdf", "E0 screening gate")
        pygoss_case()
        print("E0 grid:", json.dumps(s0["grid"], indent=0)[:400])
    if which in ("all", "e1"):
        s1 = e1_table(["results_e1a.jsonl", "results_e1b.jsonl"], "e1")
        if s1["grid"]:
            fig_invariance(s1, "fig_e1_invariance.pdf", "E1 full study")
            print("E1 arms:", s1["arms"])
    if which in ("all", "e3"):
        print("E3:", json.dumps(e3_analysis(), indent=0)[:400])
    if which in ("all", "e2"):
        e2_analysis()
        print("E2 summary written")


# ---------------- LaTeX table emission ----------------
TBLDIR = HERE.parent / "paper" / "tables"
TBLDIR.mkdir(exist_ok=True)


def emit_rq1(label: str) -> None:
    s = e1_table([f"results_{label}.jsonl"], label)
    mrs = sorted({k.split("|")[0] for k in s["grid"]})
    resolvers = sorted({k.split("|")[1] for k in s["grid"]})
    lines = [
        r"\begin{table}[t]\centering",
        r"\caption{Resolution divergence under precondition-verified "
        r"metamorphic rewrites (" + label.replace("results_", "E") + r").}",
        r"\label{tab:rq1_" + label + r"}",
        r"\small",
        r"\begin{tabular}{l" + "r" * (len(resolvers) * 2) + "}",
        r"\toprule",
        " & " + " & ".join(r"\multicolumn{2}{c}{%s}" % r for r in resolvers) + r" \\",
        " & " + " & ".join(r"\multicolumn{2}{c}{%s}" % r for r in resolvers) + r" \\".replace("\\\\", r"\cmidrule(lr){2-%d}" % (1 + 2 * len(resolvers))),
        r"MR & " + " & ".join("N & \\%%div" for _ in resolvers) + r" \\",
        r"\midrule",
    ]
    for mr in mrs:
        cells = []
        for res in resolvers:
            g = s["grid"].get(f"{mr}|{res}")
            if g:
                cells += [str(g["n"]), f"{100*g['rate']:.2f}"]
            else:
                cells += ["--", "--"]
        lines.append(f"{mr} & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TBLDIR / f"rq1_{label}.tex").write_text("\n".join(lines))
    return s


def emit_e3() -> None:
    recs = load("drift_results.jsonl")
    ok = [r for r in recs if r.get("status") == "OK"]
    fails = [r for r in recs if r.get("status") == "RESOLVE_FAIL"]
    from collections import defaultdict
    per = defaultdict(lambda: {"ok": 0, "fail": 0, "drifts": [], "cascade": 0})
    spec_block = {"raw": 0, "bounded": 1, "cap": 3, "pin": 3}  # analytic: of 3 futures
    for r in ok + fails:
        pol = r["policy"]
        if r.get("status") == "OK":
            per[pol]["ok"] += 1
            per[pol]["drifts"].append(r["drift_members"])
            if r["drift_members"] > 1:
                per[pol]["cascade"] += 1
        else:
            per[pol]["fail"] += 1
    lines = [
        r"\begin{table}[t]\centering",
        r"\caption{Re-resolution drift exposure under synthetic upstream releases "
        r"(null model: future metadata identical). Blocked = futures excluded by "
        r"the policy (analytic).}",
        r"\label{tab:e3}",
        r"\small",
        r"\begin{tabular}{lrrrrr}",
        r"\toprule",
        r"Policy & Resolved & Unsatisfiable & Drift$>$0 & Cascade$>$1 & Blocked \\",
        r"\midrule",
    ]
    for pol in ("raw", "bounded", "cap", "pin"):
        d = per[pol]
        drifts = d["drifts"]
        lines.append(
            f"{pol} & {d['ok']} & {d['fail']} & "
            f"{sum(1 for x in drifts if x > 0)} & {d['cascade']} & "
            f"{spec_block[pol]}/3 \\\\"
        )
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TBLDIR / "e3.tex").write_text("\n".join(lines))
