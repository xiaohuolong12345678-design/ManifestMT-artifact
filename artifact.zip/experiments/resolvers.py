"""ManifestMT resolver adapters: uv, pip-tools, poetry, pdm.

Each adapter resolves a list of PEP 508 requirement strings in a clean
working directory against the frozen mirror index and returns
{normalized_name: version} or raises ResolverError(kind, message).
"""
from __future__ import annotations
import json, os, re, subprocess, sys, tempfile, tomllib
from pathlib import Path

MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"
PATH_PREPEND = "/home/xiaohuolong/miniconda3/bin:/home/xiaohuolong/.local/bin:"
ENV = {
    **{k: (PATH_PREPEND + v if k == "PATH" else v) for k, v in os.environ.items()},
    "POETRY_NO_INTERACTION": "1",
    "POETRY_VIRTUALENVS_CREATE": "false",
    "POETRY_CACHE_DIR": "/tmp/mmt/poetry_cache",
    "PDM_CACHE_DIR": "/tmp/mmt/pdm_cache",
    "UV_NO_PROGRESS": "1",
    "PIP_DISABLE_PIP_VERSION_CHECK": "1",
    "UV_PYTHON": "/home/xiaohuolong/miniconda3/bin/python3",
    "POETRY_PYTHON": "/home/xiaohuolong/miniconda3/bin/python3",
    "PIP_NO_WARN_SCRIPT_LOCATION": "1",
    "PIP_CACHE_DIR": "/tmp/mmt/pipcache",
}


class ResolverError(Exception):
    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind  # UNSAT | PARSE | TIMEOUT | CRASH


def _norm(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _run(cmd: list[str], cwd: Path, timeout: int) -> str:
    try:
        p = subprocess.run(
            cmd, cwd=str(cwd), env=ENV, capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired as e:
        raise ResolverError("TIMEOUT", f"{cmd[0]} timeout after {timeout}s") from e
    if p.returncode != 0:
        tail = (p.stderr or p.stdout or "")[-1500:]
        low = tail.lower()
        if ("no matching distribution" in low or "conflict is caused by" in low
                or "resolutionimpossible" in low or "cannot install" in low
                or "could not find a version" in low
                or ("depend on" in low and "conflict" in low)):
            raise ResolverError("UNSAT", tail)
        raise ResolverError("CRASH", tail)
    return p.stdout


def _write_requirements(lines: list[str], d: Path) -> Path:
    f = d / "requirements.in"
    f.write_text("\n".join(lines) + "\n")
    return f


def _parse_pin_lines(text: str) -> dict[str, str]:
    pins = {}
    for line in text.splitlines():
        m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(\[[^\]]*\])?\s*==\s*([^\s;]+)", line.strip())
        if m:
            pins[_norm(m.group(1))] = m.group(3)
    return pins


# ---------------- uv ----------------
def resolve_uv(lines: list[str], d) -> dict[str, str]:
    d = Path(d)
    req = _write_requirements(lines, d)
    out = d / "uv.lock.txt"
    _run(
        ["uv", "pip", "compile", str(req), "-o", str(out),
         "--index-url", MIRROR, "--no-header", "--quiet", "--no-annotate"],
        d, timeout=90,
    )
    return _parse_pin_lines(out.read_text())


# ---------------- pip-tools ----------------
def resolve_piptools(lines: list[str], d) -> dict[str, str]:
    d = Path(d)
    req = _write_requirements(lines, d)
    out = d / "pt.lock.txt"
    _run(
        ["pip-compile", str(req), "-o", str(out), "--index-url", MIRROR,
         "--no-header", "--no-annotate", "--no-strip-extras", "--quiet",
         "--resolver", "backtracking"],
        d, timeout=180,
    )
    return _parse_pin_lines(out.read_text())


# ---------------- poetry (PEP 621 [project]) ----------------
def _pyproject_project(lines: list[str], name: str = "manifestmt-probe") -> dict:
    return {
        "project": {
            "name": name,
            "version": "0.0.1",
            "requires-python": ">=3.9",
            "dependencies": lines,
        }
    }


def resolve_poetry(lines: list[str], d) -> dict[str, str]:
    d = Path(d)
    pyproj = _pyproject_project(lines)
    pyproj["tool"] = {"poetry": {"source": [
        {"name": "mirror", "priority": "primary", "url": MIRROR}
    ]}}
    import tomli_w
    (d / "pyproject.toml").write_text(tomli_w.dumps(pyproj))
    _run(["poetry", "lock"], d, timeout=300)
    data = tomllib.loads((d / "poetry.lock").read_text())
    pins = {}
    for pkg in data.get("package", []):
        pins[_norm(pkg["name"])] = pkg["version"]
    return pins


# ---------------- pdm ----------------
def resolve_pdm(lines: list[str], d) -> dict[str, str]:
    d = Path(d)
    pyproj = _pyproject_project(lines)
    pyproj["tool"] = {"pdm": {"source": [
        {"name": "pypi", "url": MIRROR, "verify_ssl": True}
    ]}}
    import tomli_w
    (d / "pyproject.toml").write_text(tomli_w.dumps(pyproj))
    (d / "__pypackages__").mkdir(exist_ok=True)
    _run(["pdm", "lock", "--lockfile", "pdm.lock", "-q"], d, timeout=300)
    data = tomllib.loads((d / "pdm.lock").read_text())
    pins = {}
    for grp_key in ("package", "packages"):
        for pkg in data.get(grp_key, []):
            pins[_norm(pkg["name"])] = pkg["version"]
    if not pins:
        raise ResolverError("PARSE", "pdm.lock empty/unparsed")
    return pins


# --- minimal TOML writer for the narrow structure we build ---
def _toml_str(v: str) -> str:
    return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _toml_val(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, str):
        return _toml_str(v)
    if isinstance(v, list):
        return "[" + ", ".join(_toml_val(x) for x in v) + "]"
    raise TypeError(type(v))


def tomllib_format(table: dict) -> str:
    out: list[str] = []

    def emit(tbl: dict, prefix: str) -> None:
        scalars = {k: v for k, v in tbl.items() if not isinstance(v, dict)}
        arrays = {k: v for k, v in tbl.items() if isinstance(v, list)}
        subs = {k: v for k, v in tbl.items() if isinstance(v, dict) and not k.startswith("[[")}
        if prefix:
            out.append(f"[{prefix}]")
        for k, v in scalars.items():
            out.append(f"{k} = {_toml_val(v)}")
        for k, v in arrays.items():
            if all(isinstance(x, dict) for x in v):
                for item in v:
                    out.append("")
                    out.append(f"[[{prefix + '.' if prefix else ''}{k}]]")
                    for ik, iv in item.items():
                        out.append(f"{ik} = {_toml_val(iv)}")
            else:
                out.append(f"{k} = {_toml_val(v)}")
        for k, v in subs.items():
            out.append("")
            emit(v, f"{prefix + '.' if prefix else ''}{k}")

    emit(table, "")
    return "\n".join(out) + "\n"


RESOLVERS = {
    "uv": resolve_uv,
    "pip-tools": resolve_piptools,
    "poetry": resolve_poetry,
    "pdm": resolve_pdm,
}


def tool_versions() -> dict[str, str]:
    import importlib.metadata as md
    out = {}
    for dist, key in [("uv", "uv"), ("pip-tools", "pip-tools"),
                      ("poetry", "poetry"), ("pdm", "pdm"),
                      ("packaging", "packaging")]:
        try:
            out[key] = md.version(dist)
        except Exception:  # noqa: BLE001
            out[key] = "?"
    out["python"] = sys.version.split()[0]
    return out
