"""ManifestMT harvest: build the manifest corpus from PyPI metadata.

Sources:
  - seeded stratum: curated high-impact packages (embedded list)
  - uniform stratum: uniform random sample of the /simple/ index
Metadata via tuna mirror JSON API (pypi.org fallback), with retries.

Output: corpus.jsonl  one record per package:
  {name, version, requires_python, requires_dist: [...], stratum, fetched_at}
"""
from __future__ import annotations
import json, random, re, sys, time, concurrent.futures as cf
import urllib.request, urllib.error
from pathlib import Path

MIRROR = "https://pypi.tuna.tsinghua.edu.cn"
FALLBACK = "https://pypi.org"
OUT = Path(__file__).resolve().parent / "data"
OUT.mkdir(parents=True, exist_ok=True)

SEEDS = """requests urllib3 certifi charset-normalizer idna setuptools wheel pip packaging
numpy scipy pandas matplotlib scikit-learn statsmodels sympy networkx pillow
django flask fastapi pydantic starlette uvicorn tornado aiohttp httpx sqlalchemy
alembic celery redis rq click typer rich tqdm pyyaml toml tomli jinja2 markupsafe
pytest pytest-asyncio pytest-xdist mock coverage hypothesis factory-boy faker
black flake8 pylint mypy isort ruff autopep8 rope
cryptography cffi pycryptodome bcrypt argon2-cffi jwt pyopenssl
beautifulsoup4 lxml html5lib soupsieve parsel squin
openai anthropic tiktoken tokenizers transformers datasets sentencepiece
torch torchvision tensorflow keras onnx onnxruntime
boto3 botocore google-cloud-storage azure-storage-blob kubernetes docker paramiko
psutil py-cpuinfo pynvml setuptools-rust cython
six python-dateutil pytz tzdata arrow pendulum
colorama termcolor wcwidth prompt-toolkit cmd2
attrs marshmallow cattrs serpy jsonschema
grpcio protobuf msgpack ujson orjson marshmallow-polyfield
elasticsearch pymongo psycopg2-binary mysqlclient pymongo-inmemory
prometheus-client opentelemetry-api sentry-sdk
zipp importlib-metadata importlib-resources more-itertools executing
regex pcre2 Levenshtein fuzzywuzzy
werkzeug itsdangerous blinker
greenlet gevent eventlet
chardet text-unidecode unidecode slugify python-slugify
tabulate prettytable humanize pyfiglet
tenacity retry backoff
qrcode pillow-snippets imageio
machine translation polyglot
""".split()

UA = {"User-Agent": "manifestmt-research/0.1 (empirical SE study)"}


def fetch_json(url: str, timeout: int = 30, tries: int = 4) -> dict | None:
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.5 * (i + 1))
    print(f"  !! fetch failed {url}: {last}", file=sys.stderr)
    return None


def pkg_meta(name: str) -> dict | None:
    d = fetch_json(f"{MIRROR}/pypi/{name}/json") or fetch_json(f"{FALLBACK}/pypi/{name}/json")
    if not d or not d.get("info"):
        return None
    info = d["info"]
    rd = info.get("requires_dist")
    if rd is None:
        return None
    return {
        "name": info["name"],
        "version": info.get("version"),
        "requires_python": info.get("requires_python"),
        "requires_dist": rd,
        "stratum": "seed",
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }


def simple_index_names(limit_sample: int, seed: int = 20260904) -> list[str]:
    """Uniform sample from the mirror's /simple/ index (name -> anchor lines)."""
    url = f"{MIRROR}/simple/"
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=120) as r:
        text = r.read().decode("utf-8", "replace")
    names = re.findall(r">([^<]+)</a>", text)
    names = [n for n in names if re.fullmatch(r"[A-Za-z0-9._-]+", n)]
    rnd = random.Random(seed)
    rnd.shuffle(names)
    return names[:limit_sample]


def main(n_uniform: int = 900, workers: int = 8) -> None:
    seeds = sorted(set(SEEDS))
    print(f"seed stratum: {len(seeds)}")
    uni = simple_index_names(n_uniform)
    print(f"uniform stratum: {len(uni)}")
    allnames = [(n, "seed") for n in seeds] + [(n, "uniform") for n in uni]

    out_path = OUT / "corpus.jsonl"
    seen = set()
    n_ok = 0
    with out_path.open("w") as out, cf.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(pkg_meta, n): (n, st) for n, st in allnames}
        for fut in cf.as_completed(futs):
            n, st = futs[fut]
            try:
                rec = fut.result()
            except Exception:  # noqa: BLE001
                continue
            if not rec or n.lower() in seen:
                continue
            if len(rec["requires_dist"]) < 1:  # need at least one dep
                continue
            seen.add(n.lower())
            rec["stratum"] = st
            out.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_ok += 1
    print(f"corpus records: {n_ok} -> {out_path}")


if __name__ == "__main__":
    main()
