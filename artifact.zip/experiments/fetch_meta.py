"""Standalone metadata prefetcher for E3/E2.

Fetches per-(pkg, version) PyPI JSON metadata into CACHE with stubborn
retries, so the resolution phases never touch the flaky network.

Output: CACHE/m_<pkg>_<ver>.json  =  {"requires_dist": [...], "requires_python": ...}
"""
from __future__ import annotations
import json, re, sys, time, urllib.request
from pathlib import Path

UA = {"User-Agent": "manifestmt-research/0.1"}
CACHE = Path("/tmp/mmt/drift_cache")
CACHE.mkdir(parents=True, exist_ok=True)
HERE = Path(__file__).resolve().parent


def fetch(url: str) -> dict | None:
    for i in range(10):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=25) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None  # permanent
            time.sleep(min(1.5 * (i + 1), 10))
        except Exception:  # noqa: BLE001
            time.sleep(min(1.5 * (i + 1), 10))
    return None


def pep440_sorted(versions) -> list[str]:
    from packaging.version import Version
    ok = []
    for v in versions:
        try:
            Version(v)
            ok.append(v)
        except Exception:  # noqa: BLE001
            pass
    return sorted(ok, key=Version)


def main(top: int = 200) -> None:
    corpus = [json.loads(l) for l in open(HERE / "data" / "corpus.jsonl")]
    projects = corpus[:top]
    # version lists per pkg come from the package-level endpoint (tuna mirrors it)
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name

    n_have, n_miss = 0, 0
    for proj in projects:
        manifest = [l for l in proj["requires_dist"] if isinstance(l, str) and l.strip()]
        seen = set()
        picks = []
        for ln in manifest:
            try:
                r = Requirement(ln)
            except Exception:  # noqa: BLE001
                continue
            nm = canonicalize_name(r.name)
            if r.url or nm in seen:
                continue
            seen.add(nm)
            picks.append(nm)
        for nm in picks[:3]:
            vf = CACHE / f"v_{nm}.json"
            if vf.exists():
                vs = json.loads(vf.read_text())
            else:
                d = fetch(f"https://pypi.tuna.tsinghua.edu.cn/pypi/{nm}/json")
                if not d:
                    d = fetch(f"https://pypi.org/pypi/{nm}/json")
                vs = pep440_sorted((d or {}).get("releases", {}).keys())
                vf.write_text(json.dumps(vs))
            if not vs:
                continue
            top = vs[-1]
            mf = CACHE / f"m_{nm}_{top}.json"
            if mf.exists():
                n_have += 1
                continue
            d = None
            for base in ("https://pypi.org/pypi", "https://pypi.tuna.tsinghua.edu.cn/pypi"):
                d = fetch(f"{base}/{nm}/{top}/json")
                if d and d.get("info"):
                    break
                d = None
            if not d:
                print(f"MISS {nm} {top}", flush=True)
                n_miss += 1
                continue
            info = d["info"]
            meta = {"requires_dist": info.get("requires_dist") or [],
                    "requires_python": info.get("requires_python"),
                    "version": top}
            mf.write_text(json.dumps(meta))
            n_have += 1
    print(f"prefetch done: have={n_have} miss={n_miss}", flush=True)


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 200)
