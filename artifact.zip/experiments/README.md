# ManifestMT artifact

Reproducibility package for "Are Equivalent Dependency Declarations
Equivalent? Metamorphic Testing of Python Package Manifests".

## Contents
- harvest.py          corpus builder (PyPI JSON API -> corpus.jsonl)
- resolvers.py        uv / pip-tools / Poetry / PDM adapters
- mrs.py              MR families MR1-MR6 with executable preconditions
- runner.py           scenario runner (baseline + arms, --append resume)
- replay.py           clean-replay classifier (taxonomy of Section outcomes)
- impact.py           E2 test-impact arm
- drift.py            E3 drift prober (synthetic futures, local PEP 503 index)
- fetch_meta.py       metadata prefetcher
- analyze.py          tables/figures/summary generation
- data/               corpus + all raw result JSONL files

## Environment
CPython 3.13.9, Linux x86-64; uv 0.12.7, pip-tools 7.6.1, Poetry 2.4.2,
PDM 2.29.0; single index (Tsinghua PyPI mirror). Experiment interpreter
pinned via UV_PYTHON in resolvers.py.

## Regenerate every number in the paper
    python3 analyze.py all
Tables land in ../paper/tables/, figures in ../paper/figs/.
