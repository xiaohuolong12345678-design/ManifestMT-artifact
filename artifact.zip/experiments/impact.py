"""E2 impact arm: do developer-plausible manifest rewrites change test outcomes?

For each sampled PyPI package (with bundled tests + >=2 releases of some
direct dependency):
  1. build 3 fresh venvs: baseline, CAP (X<top), PIN_OLD (X==prev)
  2. `pip install . + pytest` under the arm's constraint file
  3. run pytest twice per arm (baseline rerun for flaky exclusion)
  4. record per-test outcomes -> breakage stats + paired McNemar

Output: data/impact_results.jsonl (one record per project per arm)
"""
from __future__ import annotations
import argparse, json, os, re, subprocess, sys, tarfile, tempfile, zipfile, time
from pathlib import Path

import urllib.request

UA = {"User-Agent": "manifestmt-research/0.1"}
MIRROR_JSON = "https://pypi.tuna.tsinghua.edu.cn/pypi"
MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"
HERE = Path(__file__).resolve().parent
CACHE = Path("/tmp/mmt/impact_cache")
CACHE.mkdir(parents=True, exist_ok=True)


def _pep440_sorted(versions) -> list[str]:
    from packaging.version import Version, InvalidVersion
    valid = [v for v in versions if not str(v).endswith(".*")]
    ok = [v for v in valid if _can_version(v)]
    return sorted(ok, key=Version)


def _can_version(v: str) -> bool:
    try:
        from packaging.version import Version
        Version(v)
        return True
    except Exception:  # noqa: BLE001
        return False


def fetch_json(url: str, tries: int = 3) -> dict | None:
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
                return json.loads(r.read())
        except Exception:  # noqa: BLE001
            time.sleep(1 + i)
    return None


def get_versions(pkg: str) -> list[str]:
    f = CACHE / f"versions_{pkg}.json"
    if f.exists():
        return json.loads(f.read_text())
    d = fetch_json(f"{MIRROR_JSON}/{pkg}/json") or {}
    vs = _pep440_sorted(d.get("releases", {}).keys())
    f.write_text(json.dumps(vs))
    return vs


def download_sdist(pkg: str) -> Path | None:
    f = CACHE / f"sdist_{pkg}.tar.gz"
    if f.exists():
        return f
    d = fetch_json(f"{MIRROR_JSON}/{pkg}/json")
    if not d:
        return None
    for u in d.get("urls", []):
        if u.get("packagetype") == "sdist" and (u.get("size") or 0) > 25_000_000:
            return None  # skip giant sdists
        if u.get("packagetype") == "sdist" and u.get("url", "").endswith((".tar.gz", ".zip")):
            try:
                urllib.request.urlretrieve(u["url"], f)  # mirrors redirect ok
                return f
            except Exception:  # noqa: BLE001
                return None
    return None


def extract_and_find_tests(pkg: str, arc: Path, workdir: Path) -> Path | None:
    dest = workdir / f"src_{pkg}"
    if dest.exists():
        return dest
    dest.mkdir(parents=True, exist_ok=True)
    try:
        if arc.name.endswith(".zip"):
            with zipfile.ZipFile(arc) as z:
                z.extractall(dest)
        else:
            with tarfile.open(arc) as t:
                t.extractall(dest, filter="data")
    except Exception:  # noqa: BLE001
        return None
    # project root = dir containing setup.py/pyproject/ with tests inside
    for root, dirs, _ in os.walk(dest):
        if (Path(root) / "pyproject.toml").exists() or (Path(root) / "setup.py").exists():
            has_tests = (
                (Path(root) / "tests").is_dir()
                or (Path(root) / "test").is_dir()
                or any(d in ("tests", "test") for d in dirs)
                or any(d.startswith("test_") and d.endswith(".py") for d in os.listdir(root))
                or any((Path(root) / d / "tests").is_dir() for d in dirs if d == "src")
            )
            if has_tests:
                return Path(root)
    return None


def sh(cmd: list[str], cwd: Path | None = None, timeout: int = 600, env=None):
    e = {**os.environ, "PIP_DISABLE_PIP_VERSION_CHECK": "1", "UV_NO_PROGRESS": "1"}
    if env:
        e.update(env)
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, capture_output=True,
                          text=True, timeout=timeout, env=e)


def parse_pytest_ids(text: str) -> dict[str, str]:
    """test node id -> PASSED/FAILED (from -v output)."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^(tests?/[^:]+\.(?:py|py::\S+)|\S+\.py::\S+)\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)",
                     line.strip())
        if m:
            out[m.group(1)] = m.group(2)
    return out


def run_arm(project_root: Path, dep_constraint: str | None, venv_dir: Path,
            pkg_spec: str, test_extra: str | None) -> dict | None:
    if venv_dir.exists():
        shutil.rmtree(venv_dir, ignore_errors=True)
    r = sh([sys.executable, "-m", "venv", str(venv_dir)])
    if r.returncode != 0:
        return None
    py = venv_dir / "bin" / "python"
    r = sh([str(py), "-m", "pip", "install", "-q", "-U", "pip", "pytest",
            "-i", MIRROR], timeout=600)
    if r.returncode != 0:
        return None
    if test_extra:
        r = sh([str(py), "-m", "pip", "install", "-q", f"{pkg_spec}[{test_extra}]",
                "-i", MIRROR], cwd=project_root, timeout=900)
    else:
        r = sh([str(py), "-m", "pip", "install", "-q", ".",
                "-i", MIRROR], cwd=project_root, timeout=900)
    if r.returncode != 0:
        return None
    if dep_constraint:
        cf = venv_dir / "constraint.txt"
        cf.write_text(dep_constraint + "\n")
        r = sh([str(py), "-m", "pip", "install", "-q", "-c", str(cf), pkg_spec,
                "-i", MIRROR], cwd=project_root, timeout=900)
        if r.returncode != 0:
            return {"install_error": r.stderr[-300:]}
    runs = []
    for _ in range(2):
        r = sh([str(py), "-m", "pytest", "-v", "--no-header", "--tb=no",
                "-p", "no:cacheprovider", "-x"],
               cwd=project_root, timeout=1200)
        runs.append({"rc": r.returncode, "parsed": parse_pytest_ids(r.stdout)})
    return {"runs": runs}


import shutil  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default=str(HERE / "data" / "corpus.jsonl"))
    ap.add_argument("--n", type=int, default=300, help="candidates to try")
    ap.add_argument("--target", type=int, default=10, help="green projects wanted (per worker)")
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--stride", type=int, default=4)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--out", default=str(HERE / "data" / f"impact_results_w{0}.jsonl"))
    args = ap.parse_args()

    corpus = [json.loads(l) for l in open(args.corpus)]
    pool = [p for i, p in enumerate(corpus) if i % args.stride == args.worker]
    candidates = [p for p in pool if len(p["requires_dist"]) >= 2][:args.n]

    done = set()
    if Path(args.out).exists():
        for line in open(args.out):
            try:
                done.add(json.loads(line)["project"])
            except Exception:  # noqa: BLE001
                pass
    candidates = [c for c in candidates if c["name"] not in done]
    results = []
    n_green = 0
    workroot = Path(tempfile.mkdtemp(prefix=f"mmt_e2_w{args.worker}_"))
    for proj in candidates:
        if n_green >= args.target:
            break
        name = proj["name"]
        print(f"== {name} ==", flush=True)
        arc = download_sdist(name)
        if not arc:
            continue
        root = extract_and_find_tests(name, arc, workroot)
        if not root:
            print("  no tests in sdist", flush=True)
            continue
        # pick dependency X: first parseable dep with >=2 releases
        dep = None
        for ln in proj["requires_dist"]:
            if not isinstance(ln, str):
                continue
            try:
                from packaging.requirements import Requirement
                r = Requirement(ln)
            except Exception:  # noqa: BLE001
                continue
            if r.url or r.extras:
                continue
            vs = get_versions(r.name)
            if len(vs) >= 2:
                dep = (r, vs)
                break
        if not dep:
            continue
        r, vs = dep
        top, prev = vs[-1], vs[-2]
        test_extra = None
        for ln in proj["requires_dist"]:
            if isinstance(ln, str) and 'extra == "test"' in ln:
                try:
                    from packaging.requirements import Requirement as _R
                    test_extra = _R(ln).name if _R(ln).name == name else None
                except Exception:  # noqa: BLE001
                    pass
                break
        base_arm = run_arm(root, None, workroot / f"venv_{name}_base", name, test_extra)
        if not base_arm or "install_error" in base_arm:
            print("  baseline install failed", flush=True)
            continue
        if base_arm["runs"][0]["rc"] != 0:
            print("  baseline tests not green", flush=True)
            continue
        cap_arm = run_arm(root, f"{r.name}<{top}", workroot / f"venv_{name}_cap", name, None)
        pin_arm = run_arm(root, f"{r.name}=={prev}", workroot / f"venv_{name}_pin", name, None)
        rec = {
            "project": name, "dep": r.name, "top": top, "prev": prev,
            "baseline": base_arm, "cap": cap_arm, "pin_old": pin_arm,
        }
        results.append(rec)
        n_green += 1
        with open(args.out, "w") as f:
            for x in results:
                f.write(json.dumps(x, ensure_ascii=False) + "\n")
        print(f"  ok ({n_green}/{args.target})", flush=True)
    print(f"impact arm done: {n_green} projects -> {args.out}", flush=True)


if __name__ == "__main__":
    main()
