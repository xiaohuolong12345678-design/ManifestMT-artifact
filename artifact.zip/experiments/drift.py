"""E3: re-resolution drift exposure under synthetic upstream releases.

Null model: a future release of X has the SAME metadata as X's current top
(changes nothing but the version). We synthesize such wheels (next patch /
minor / major) into a local find-links dir, then re-resolve each manifest
under four dependency-declaration policies:

  raw      : manifest as published
  bounded  : X>=top,<next-major  (admits within-major futures)
  cap      : X<top               (blocks all futures)
  pin      : X==top              (blocks all futures)

Metrics per (project, dep, policy):
  drift_members : |closure delta| after futures admitted by the policy
  blocked       : # synthetic futures excluded by the policy (staleness)
"""
from __future__ import annotations
import argparse, json, os, re, shutil, tempfile, time, urllib.request
from pathlib import Path

UA = {"User-Agent": "manifestmt-research/0.1"}
MIRROR_JSON = "https://pypi.tuna.tsinghua.edu.cn/pypi"
MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"
HERE = Path(__file__).resolve().parent
CACHE = Path("/tmp/mmt/drift_cache")
CACHE.mkdir(parents=True, exist_ok=True)


def _pep440_sorted(versions) -> list[str]:
    from packaging.version import Version, InvalidVersion
    valid = [v for v in versions if not str(v).endswith(".*")]
    ok = [v for v in valid if _can_version(v)]
    return sorted(ok, key=Version)


def _can_version(v: str) -> bool:
    try:
        from packaging.version import Version
        Version(v)
        return True
    except Exception:  # noqa: BLE001
        return False


def fetch_json(url: str) -> dict | None:
    import time
    for i in range(8):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
                return json.loads(r.read())
        except Exception:  # noqa: BLE001
            time.sleep(min(2.0 * (i + 1), 12))
    return None


def versions_of(pkg: str) -> list[str]:
    vf = CACHE / f"v_{pkg}.json"
    if vf.exists():
        return json.loads(vf.read_text())
    from fetch_meta import fetch, pep440_sorted
    d = fetch(f"https://pypi.tuna.tsinghua.edu.cn/pypi/{pkg}/json") or \
        fetch(f"https://pypi.org/pypi/{pkg}/json")
    vs = pep440_sorted((d or {}).get("releases", {}).keys())
    vf.write_text(json.dumps(vs))
    return vs


def meta_of(pkg: str, ver: str) -> dict | None:
    mf = CACHE / f"m_{pkg}_{ver}.json"
    if mf.exists():
        return json.loads(mf.read_text())
    from fetch_meta import fetch
    d = None
    for base in ("https://pypi.org/pypi", "https://pypi.tuna.tsinghua.edu.cn/pypi"):
        d = fetch(f"{base}/{pkg}/{ver}/json")
        if d and d.get("info"):
            break
        d = None
    if not d:
        return None
    info = d["info"]
    meta = {"requires_dist": info.get("requires_dist") or [],
            "requires_python": info.get("requires_python"), "version": ver}
    mf.write_text(json.dumps(meta))
    return meta


def bump(ver: str, level: str) -> str | None:
    m = re.match(r"^(\d+)\.(\d+)(?:\.(\d+))?", ver)
    if not m:
        return None
    X, Y, Z = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
    if level == "patch":
        return f"{X}.{Y}.{Z + 1}"
    if level == "minor":
        return f"{X}.{Y + 1}.0"
    if level == "major":
        return f"{X + 1}.0.0"
    return None


def synth_wheel(pkg: str, ver: str, requires_dist: list[str], requires_python: str | None,
                outdir: Path) -> bool:
    """Minimal valid wheel with the given metadata (null-model future release)."""
    try:
        from packaging.tags import Tag
    except ImportError:
        return False
    sname = re.sub(r"[-_.]+", "_", pkg)
    sver = ver
    dist = f"{sname}-{sver}.dist-info"
    lines = ["Metadata-Version: 2.1", f"Name: {pkg}", f"Version: {sver}"]
    if requires_python:
        lines.append(f"Requires-Python: {requires_python}")
    for rd in requires_dist:
        lines.append(f"Requires-Dist: {rd}")
    files = {
        f"{dist}/METADATA": "\n".join(lines) + "\n",
        f"{dist}/WHEEL": ("Wheel-Version: 1.0\nGenerator: manifestmt-synth\n"
                          "Root-Is-Purelib: true\nTag: py3-none-any\n"),
        f"{dist}/RECORD": "",
    }
    record_lines = []
    outdir.mkdir(parents=True, exist_ok=True)
    whl = outdir / f"{sname}-{sver}-py3-none-any.whl"
    import zipfile
    with zipfile.ZipFile(whl, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, content in files.items():
            if rel.endswith("RECORD"):
                continue
            z.writestr(rel, content)
            record_lines.append(f"{rel},,")
        record_lines.append(f"{dist}/RECORD,,")
        z.writestr(f"{dist}/RECORD", "\n".join(record_lines) + "\n")
    return whl


def build_local_index(pkg: str, wheels: dict[str, Path], root: Path) -> Path:
    """PEP 503 simple index hosting only the synthetic wheels."""
    name = re.sub(r"[-_.]+", "-", pkg).lower()
    idx = root / name
    if idx.exists():
        shutil.rmtree(idx)
    idx.mkdir(parents=True)
    links = []
    for fv, src in wheels.items():
        fname = src.name
        (idx / fname).write_bytes(src.read_bytes())
        links.append(f'<a href="{fname}">{fv}</a><br>')
    (idx / "index.html").write_text("<html><body>" + "".join(links) + "</body></html>")
    return root


_RES_COUNTER = [0]


def uv_resolve(lines: list[str], workdir: Path, local_index: Path | None = None) -> dict[str, str]:
    import sys
    _RES_COUNTER[0] += 1
    req = workdir / f"requirements_{_RES_COUNTER[0]}.in"
    req.write_text("\n".join(lines) + "\n")
    out = workdir / f"out_{_RES_COUNTER[0]}.txt"
    cmd = ["uv", "pip", "compile",
           str(req), "-o", str(out), "--index-url", MIRROR, "--no-header",
           "--no-annotate"]
    if local_index is not None:
        cmd += ["--extra-index-url", local_index.as_uri(),
                "--index-strategy", "unsafe-best-match"]
    p = subprocess_run(cmd, workdir)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-300:])
    pins = {}
    for line in out.read_text().splitlines():
        m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(\[[^\]]*\])?\s*==\s*([^\s;]+)", line.strip())
        if m:
            pins[re.sub(r"[-_.]+", "-", m.group(1)).lower()] = m.group(3)
    return pins


import subprocess  # noqa: E402


def subprocess_run(cmd, cwd):
    import os
    env = {**os.environ, "PIP_DISABLE_PIP_VERSION_CHECK": "1", "UV_NO_PROGRESS": "1"}
    return subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True,
                          timeout=120, env=env)


def replace_dep_spec(lines: list[str], dep: str, new_spec: str | None) -> list[str]:
    """Rewrite every constraint line for `dep`; new_spec None = drop dep lines."""
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name
    out = []
    for ln in lines:
        try:
            r = Requirement(ln)
        except Exception:  # noqa: BLE001
            out.append(ln)
            continue
        if canonicalize_name(r.name) == dep:
            if new_spec is None:
                continue
            marker = f" ; {r.marker}" if r.marker else ""
            extras = f"[{','.join(sorted(r.extras))}]" if r.extras else ""
            out.append(f"{r.name}{extras}{new_spec}{marker}")
        else:
            out.append(ln)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default=str(HERE / "data" / "corpus.jsonl"))
    ap.add_argument("--n", type=int, default=120)
    ap.add_argument("--skip", type=int, default=0)
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--out", default=str(HERE / "data" / "drift_results.jsonl"))
    args = ap.parse_args()

    corpus = [json.loads(l) for l in open(args.corpus)]
    projects = [p for i, p in enumerate(corpus) if i % 3 == args.worker]
    done = set()
    if Path(args.out).exists():
        for line in open(args.out):
            try:
                done.add(json.loads(line)["project"])
            except Exception:  # noqa: BLE001
                pass
    projects = [p for p in projects if p["name"] not in done][:args.n]
    out = open(args.out, "a")
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name
    n_ok = 0
    for proj in projects:
        manifest = [l for l in proj["requires_dist"] if isinstance(l, str) and l.strip()]
        if not manifest:
            continue
        seen = set()
        dep_names = []
        for ln in manifest:
            try:
                r = Requirement(ln)
            except Exception:  # noqa: BLE001
                continue
            nm = canonicalize_name(r.name)
            if r.url or nm in seen:
                continue
            seen.add(nm)
            dep_names.append(nm)
            if len(dep_names) == 2:
                break
        if not dep_names:
            continue
        wd = Path(tempfile.mkdtemp(prefix="mmt_e3_"))
        try:
            try:
                c0 = uv_resolve(manifest, wd)
            except Exception as e:  # noqa: BLE001
                out.write(json.dumps({"project": proj["name"], "status": "BASELINE_FAIL",
                                      "error": str(e)[-400:]}) + "\n")
                continue
            for dep in dep_names:
                top = c0.get(dep)
                if not top or not re.match(r"^\d+\.\d+\.\d+$", top):
                    continue
                meta = meta_of(dep, top)
                if not meta:
                    out.write(json.dumps({"project": proj["name"], "dep": dep, "top": top,
                                          "status": "META_FAIL"}) + "\n")
                    continue
                fut_root = CACHE / f"idx_{proj['name']}_{dep}_{os.getpid()}_{time.time_ns() % 10**9}"
                if fut_root.exists():
                    shutil.rmtree(fut_root, ignore_errors=True)
                fut_root.mkdir(parents=True)
                wheels = {}
                for lv in ("patch", "minor", "major"):
                    fv = bump(top, lv)
                    if fv:
                        w = synth_wheel(dep, fv, meta["requires_dist"],
                                        meta["requires_python"], fut_root / "pkgs")
                        if w:
                            wheels[fv] = w
                if len(wheels) != 3:
                    continue
                local_index = build_local_index(dep, wheels, fut_root)
                policies = {
                    "raw": manifest,
                    "bounded": replace_dep_spec(manifest, dep, f">={top},<{int(top.split('.')[0]) + 1}.0"),
                    "cap": replace_dep_spec(manifest, dep, f"<{top}"),
                    "pin": replace_dep_spec(manifest, dep, f"=={top}"),
                }
                for pol, lines in policies.items():
                    rec = {"project": proj["name"], "dep": dep, "top": top,
                           "policy": pol, "levels": sorted(wheels)}
                    try:
                        p0 = uv_resolve(lines, wd)
                        p1 = uv_resolve(lines, wd, local_index)
                    except Exception as e:  # noqa: BLE001
                        rec.update(status="RESOLVE_FAIL", error=str(e)[:160])
                        out.write(json.dumps(rec) + "\n")
                        continue
                    drift = len(set(p1) ^ set(p0)) + sum(
                        1 for k in set(p1) & set(p0) if p1[k] != p0[k])
                    futures_in = sorted(fv for fv in wheels if p1.get(dep) == fv)
                    rec.update(status="OK", p0=pp(p0), p1=pp(p1),
                               drift_members=drift,
                               chosen_dep_version=p1.get(dep),
                               p0_dep_version=p0.get(dep),
                               admitted=futures_in,
                               blocked=sorted(fv for fv in wheels if fv not in futures_in))
                    out.write(json.dumps(rec) + "\n")
                shutil.rmtree(fut_root, ignore_errors=True)
            n_ok += 1
            out.flush()
            if n_ok % 10 == 0:
                print(f"[w{args.worker}] {n_ok} projects done", flush=True)
        finally:
            shutil.rmtree(wd, ignore_errors=True)
    out.close()
    print(f"[w{args.worker}] drift done", flush=True)


def pp(pins: dict) -> dict:
    """compact pin map for storage"""
    return {k: v for k, v in pins.items()}


if __name__ == "__main__":
    main()
